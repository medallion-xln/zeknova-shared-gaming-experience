/** One Three module/core graph per page. This adapter owns only its local canvas. */
export async function createViewport({three:THREE,canvas,renderer='auto',onSelect=()=>{},onPreview=()=>{},onCommit=()=>{},onError=()=>{}}){
 if(!THREE?.WebGPURenderer)throw Error('shared Three WebGPURenderer namespace required');
 let gpu,backend,fallback=null;
 try{if(renderer==='webgl'||!navigator.gpu)throw Error(renderer==='webgl'?'explicit WebGL':'WebGPU unavailable');gpu=new THREE.WebGPURenderer({canvas,antialias:true});await gpu.init();backend=gpu.backend.isWebGPUBackend?'webgpu':'webgl';}
 catch(error){gpu?.dispose();fallback=String(error.message);gpu=new THREE.WebGPURenderer({canvas,antialias:true,forceWebGL:true});await gpu.init();backend='webgl';}
 gpu.setPixelRatio(Math.min(devicePixelRatio,1.5));gpu.setClearColor(0x171b22);const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(42,1,.1,200);camera.position.set(13,16,19);camera.lookAt(0,0,0);
 const grid=new THREE.GridHelper(20,20,0x526278,0x303a48);grid.position.y=.01;scene.add(grid);
 const ghosts=new THREE.Group();scene.add(ghosts);
 function previewDiff(diff){for(const item of [...ghosts.children]){ghosts.remove(item);item.material.dispose();}if(!diff)return;for(const [entities,color] of [[diff.add,0x8edbb7],[diff.remove,0xf4867f],[diff.change.map(c=>c.after),0xe5bf79]])for(const e of entities){const t=e.components.transform,m=e.components.mesh;if(!t||!m)continue;const ghost=new THREE.Mesh(geo[m.primitive],new THREE.MeshBasicMaterial({color,wireframe:true,depthTest:false,transparent:true,opacity:.8}));ghost.position.fromArray(t.position);ghost.rotation.fromArray(t.rotation);ghost.scale.fromArray(t.scale);ghost.renderOrder=12;ghosts.add(ghost);}}
 const meshes=new Map(),gizmo=new THREE.Group();scene.add(gizmo);let selected=null,entities=[],drag=null,disposed=false;
 const ray=new THREE.Raycaster(),pointer=new THREE.Vector2(),plane=new THREE.Plane(),scratch=new THREE.Vector3();
 const geo={box:new THREE.BoxGeometry(),sphere:new THREE.SphereGeometry(.5,16,12),cylinder:new THREE.CylinderGeometry(.5,.5,1,16)};
 const arrows=[];
 for(const [axis,color] of [['x',0xf4867f],['z',0x7aaaff]]){const handle=new THREE.Mesh(new THREE.BoxGeometry(axis==='x'?1.5:.13,.13,axis==='z'?1.5:.13),new THREE.MeshBasicMaterial({color,depthTest:false}));handle.position[axis]=1;handle.userData.axis=axis;handle.renderOrder=10;gizmo.add(handle);arrows.push(handle);}
 const highlight=new THREE.BoxHelper(undefined,0xf2c66d);highlight.visible=false;scene.add(highlight);
 function cast(event){const r=canvas.getBoundingClientRect();pointer.set((event.clientX-r.left)/r.width*2-1,-(event.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);}
 function sync(data,selection=selected,preview=null){entities=data;selected=selection;const seen=new Set();for(const e of data){const t=e.components.transform,m=e.components.mesh;if(!t||!m)continue;seen.add(e.id);let object=meshes.get(e.id);
 if(object&&object.userData.primitive!==m.primitive){scene.remove(object);object.material.dispose();meshes.delete(e.id);object=null;}
 if(!object){object=new THREE.Mesh(geo[m.primitive],new THREE.MeshBasicMaterial({color:m.color}));object.userData={id:e.id,primitive:m.primitive};meshes.set(e.id,object);scene.add(object);}
 const value=e.id===selection&&preview?preview:t;object.position.fromArray(value.position);object.rotation.fromArray(value.rotation);object.scale.fromArray(value.scale);object.material.color.set(m.color);}
 for(const [id,object] of meshes)if(!seen.has(id)){scene.remove(object);object.material.dispose();meshes.delete(id);}
 const object=meshes.get(selection);highlight.visible=!!object;gizmo.visible=!!object;if(object){highlight.setFromObject(object);gizmo.position.copy(object.position);gizmo.position.y+=.8;}
 }
 const down=e=>{if(e.button!==0)return;cast(e);const hit=selected&&gizmo.visible?ray.intersectObjects(arrows)[0]:null;
 if(hit){const entity=entities.find(x=>x.id===selected);if(!entity)return;plane.set(new THREE.Vector3(0,1,0),-entity.components.transform.position[1]);if(!ray.ray.intersectPlane(plane,scratch))return;drag={id:selected,axis:hit.object.userData.axis,start:scratch.clone(),original:structuredClone(entity.components.transform),value:null};canvas.setPointerCapture(e.pointerId);return;}
 const object=ray.intersectObjects([...meshes.values()])[0]?.object;onSelect(object?.userData.id??null);};
 const move=e=>{if(!drag)return;cast(e);if(!ray.ray.intersectPlane(plane,scratch))return;const value=structuredClone(drag.original),index=drag.axis==='x'?0:2;value.position[index]+=scratch[drag.axis]-drag.start[drag.axis];value.position[index]=Math.round(value.position[index]*100)/100;drag.value=value;sync(entities,drag.id,value);onPreview(drag.id,value);};
 const up=e=>{if(!drag)return;const done=drag;drag=null;try{if(done.value)onCommit(done.id,done.value);}catch(error){onError(error);}if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);};
 const cancel=()=>{drag=null;onPreview(null,null);sync(entities,selected);};canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',cancel);
 function render(){if(disposed)return;const r=canvas.getBoundingClientRect();if(r.width<1||r.height<1)return;gpu.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();gpu.render(scene,camera);}
 function project(point){const v=new THREE.Vector3(...point).project(camera),r=canvas.getBoundingClientRect();return{x:r.left+(v.x+1)*r.width/2,y:r.top+(1-v.y)*r.height/2};}
 return{sync,render,previewDiff,backend,fallback,project,entityPoint(id){const m=meshes.get(id);return m?project(m.position.toArray()):null;},handlePoint(axis){const h=arrows.find(x=>x.userData.axis===axis);return h&&gizmo.visible?project(h.getWorldPosition(new THREE.Vector3()).toArray()):null;},metrics(){return{backend,objects:meshes.size,geometries:gpu.info.memory.geometries,drawCalls:gpu.info.render.calls??gpu.info.render.drawCalls};},dispose(){if(disposed)return;disposed=true;previewDiff(null);for(const [name,fn] of [['pointerdown',down],['pointermove',move],['pointerup',up],['pointercancel',cancel]])canvas.removeEventListener(name,fn);for(const m of meshes.values())m.material.dispose();meshes.clear();for(const g of Object.values(geo))g.dispose();for(const h of arrows){h.geometry.dispose();h.material.dispose();}highlight.geometry.dispose();highlight.material.dispose();grid.geometry.dispose();grid.material.dispose();gpu.dispose();}};
}

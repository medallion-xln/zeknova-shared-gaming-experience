import { EngineKernel } from '../../core/src/index.js';
import { AssetService } from '../../assets/src/AssetService.js';
export { AssetService };
export const SDK_VERSION='0.1.0-preview.10';
const copy=value=>structuredClone(value);
const idOK=v=>typeof v==='string'&&/^[a-zA-Z0-9_.:-]{1,100}$/.test(v);
function requireOK(ok,message){if(!ok)throw new Error(message);}
export function plain(value){
 const visit=(v,depth=0)=>{requireOK(depth<40,'data nesting limit');if(v===null||typeof v==='boolean'||typeof v==='string')return;
 if(typeof v==='number'){requireOK(Number.isFinite(v),'finite numbers required');return;}
 requireOK(v&&typeof v==='object'&&(Array.isArray(v)||Object.getPrototypeOf(v)===Object.prototype||Object.getPrototypeOf(v)===null),'plain JSON required');
 for(const [k,x] of Object.entries(v)){requireOK(!['__proto__','constructor','prototype'].includes(k),'unsafe key');visit(x,depth+1);}};
 visit(value);requireOK(JSON.stringify(value).length<=4*1024*1024,'scene size limit');return copy(value);
}
const vector=(v,positive=false)=>Array.isArray(v)&&v.length===3&&v.every(n=>Number.isFinite(n)&&Math.abs(n)<=100000&&(!positive||n>0));
export const transform=(value={})=>({position:[0,0,0],rotation:[0,0,0],scale:[1,1,1],...plain(value)});
const defaults=()=>new Map([
 ['transform',v=>v&&vector(v.position)&&vector(v.rotation)&&vector(v.scale,true)],
 ['mesh',v=>v&&['box','sphere','cylinder'].includes(v.primitive)&&/^#[0-9a-f]{6}$/i.test(v.color)],
 ['collider',v=>v&&vector(v.halfSize,true)],['state',v=>v&&typeof v==='object'&&!Array.isArray(v)],
 ['asset',v=>v&&idOK(v.id)]
]);
/** Versioned data store with atomic optimistic local transactions. Never connects to PHP/SQL. */
export class Scene {
 #data; #types; #prefabs; #assetIds; #undo=[]; #redo=[]; #listeners=new Set(); #history=[];
 constructor({id='main',types=defaults(),prefabs={},assetIds=[]}={}){requireOK(idOK(id),'invalid scene id');this.#types=types;this.#prefabs=prefabs;this.#assetIds=new Set(assetIds);this.#data={schema:'zge.sdk.scene.v1',id,revision:0,nextId:1,entities:[]};}
 get revision(){return this.#data.revision;} get id(){return this.#data.id;}
 entities(){return copy(this.#data.entities);} findEntity(id){return copy(this.#data.entities.find(e=>e.id===id)??null);}
 serialize(){return copy(this.#data);} history(){return copy(this.#history);}
 subscribe(fn){this.#listeners.add(fn);return()=>this.#listeners.delete(fn);}
 #publish(event){for(const fn of this.#listeners){try{fn(copy(event));}catch{ /* observer cannot roll back committed state */ }}}
 validate(value){
 const s=plain(value);requireOK(s.schema==='zge.sdk.scene.v1'&&idOK(s.id)&&Number.isSafeInteger(s.revision)&&s.revision>=0&&Number.isSafeInteger(s.nextId)&&s.nextId>0&&Array.isArray(s.entities)&&s.entities.length<=10000,'invalid scene envelope');
 const ids=new Set();for(const e of s.entities){requireOK(idOK(e.id)&&!ids.has(e.id)&&typeof e.name==='string'&&e.name.length<=200&&e.components&&typeof e.components==='object'&&!Array.isArray(e.components),'invalid entity');ids.add(e.id);
 for(const [type,v] of Object.entries(e.components)){requireOK(this.#types.has(type)&&this.#types.get(type)(v)===true,`invalid component ${type}`);if(type==='asset')requireOK(this.#assetIds.has(v.id),'unknown public asset id');}}
 for(const id of ids){const m=/^entity-(\d+)$/.exec(id);if(m)requireOK(Number(m[1])<s.nextId,'nextId must exceed generated IDs');}return s;
 }
 restore(value){const valid=this.validate(value);this.#data=valid;this.#undo=[];this.#redo=[];this.#history=[];this.#publish({type:'scene:restore',revision:this.revision});return this;}
 preview(changeset){const before=this.serialize(),after=this.#apply(changeset);return {schema:'zge.sdk.diff.v1',baseRevision:this.revision,add:after.entities.filter(e=>!before.entities.some(x=>x.id===e.id)),remove:before.entities.filter(e=>!after.entities.some(x=>x.id===e.id)),change:after.entities.filter(e=>before.entities.some(x=>x.id===e.id&&JSON.stringify(x)!==JSON.stringify(e))).map(e=>({before:before.entities.find(x=>x.id===e.id),after:e}))};}
 #apply(changeset){
 const c=plain(changeset);requireOK(c.schema==='zge.sdk.changeset.v1'&&c.baseRevision===this.revision&&Array.isArray(c.operations)&&c.operations.length>0&&c.operations.length<=100,'invalid changeset or stale revision');
 const s=this.serialize();for(const op of c.operations){requireOK(op&&typeof op==='object','invalid operation');const entity=s.entities.find(e=>e.id===op.id);const exists=!!entity;
 requireOK(op.expectedExists===exists,`entity precondition failed: ${op.id}`);
 if(op.type==='CreateEntity'||op.type==='CreatePrefabInstance'){
  requireOK(!exists&&idOK(op.id),'duplicate/invalid entity');let e;
  if(op.type==='CreatePrefabInstance'){requireOK(Object.hasOwn(this.#prefabs,op.prefab),'unknown prefab');e={...copy(this.#prefabs[op.prefab]),id:op.id};if(op.transform)e.components.transform=transform(op.transform);}
  else e={id:op.id,name:op.name??op.id,components:copy(op.components??{})};if(e.components.transform)e.components.transform=transform(e.components.transform);s.entities.push(e);
 }else{requireOK(exists,`entity deleted: ${op.id}`);
 if(op.type==='DeleteEntity')s.entities=s.entities.filter(e=>e.id!==op.id);
 else if(op.type==='UpdateTransform'){requireOK(Object.hasOwn(entity.components,'transform'),'missing transform');entity.components.transform={...entity.components.transform,...plain(op.value)};}
 else if(['AddComponent','RemoveComponent','UpdateComponent'].includes(op.type)){
  requireOK(idOK(op.component),'invalid component key');const has=Object.hasOwn(entity.components,op.component);
  requireOK(op.type==='AddComponent'?!has:has,'component precondition failed');if(op.type==='RemoveComponent')delete entity.components[op.component];else entity.components[op.component]=plain(op.value);
 }else throw new Error(`unsupported operation ${op.type}`);}
 const match=/^entity-(\d+)$/.exec(op.id);if(match)s.nextId=Math.max(s.nextId,Number(match[1])+1);
 }s.revision=this.revision+1;return this.validate(s);
 }
 commit(changeset,{actor='local-author',source='human'}={}){const next=this.#apply(changeset);this.#undo.push(this.serialize());if(this.#undo.length>100)this.#undo.shift();this.#redo=[];this.#data=next;
 const record={schema:'zge.sdk.commit.v1',revision:this.revision,actor:String(actor),source:String(source),changeset:plain(changeset)};this.#history.push(record);if(this.#history.length>200)this.#history.shift();this.#publish({type:'scene:commit',...record});return this.revision;}
 changeset(operations){return{schema:'zge.sdk.changeset.v1',baseRevision:this.revision,operations:plain(operations)};}
 createEntity({id=`entity-${this.#data.nextId}`,name=id,components={}}={}){this.commit(this.changeset([{type:'CreateEntity',id,name,components,expectedExists:false}]));return this.findEntity(id);}
 updateTransform(id,value){return this.commit(this.changeset([{type:'UpdateTransform',id,value,expectedExists:true}]));}
 setComponent(id,component,value){return this.commit(this.changeset([{type:Object.hasOwn(this.findEntity(id)?.components??{},component)?'UpdateComponent':'AddComponent',id,component,value,expectedExists:true}]));}
 createPrefabInstance(prefab,id=`entity-${this.#data.nextId}`,value){this.commit(this.changeset([{type:'CreatePrefabInstance',id,prefab,expectedExists:false,...(value?{transform:value}:{})}]));return this.findEntity(id);}
 deleteEntity(id){return this.commit(this.changeset([{type:'DeleteEntity',id,expectedExists:true}]));}
 #travel(from,to,type){requireOK(from.length>0,`nothing to ${type}`);const target=from.at(-1);this.validate(target);to.push(this.serialize());from.pop();const revision=this.revision+1,nextId=Math.max(this.#data.nextId,target.nextId);this.#data={...copy(target),revision,nextId};this.#publish({type:`scene:${type}`,revision});return revision;}
 undo(){return this.#travel(this.#undo,this.#redo,'undo');} redo(){return this.#travel(this.#redo,this.#undo,'redo');}
 get canUndo(){return this.#undo.length>0;} get canRedo(){return this.#redo.length>0;}
 clearListeners(){this.#listeners.clear();}
}
export function validateProject(value){const p=plain(value);requireOK(p.schema==='zge.sdk.project.v1'&&idOK(p.id)&&typeof p.name==='string'&&idOK(p.entryWorld)&&p.worlds&&Object.hasOwn(p.worlds,p.entryWorld),'invalid project');
 requireOK(Array.isArray(p.assets)&&Array.isArray(p.plugins),'assets/plugins required');requireOK(p.plugins.every(idOK)&&new Set(p.plugins).size===p.plugins.length&&typeof p.worlds==='object'&&!Array.isArray(p.worlds)&&Object.keys(p.worlds).every(idOK),'invalid project registries');const ids=new Set();for(const a of p.assets){requireOK(idOK(a.id)&&!ids.has(a.id)&&typeof a.path==='string'&&!a.path.includes('..')&&!/[\\:?#]/.test(a.path)&&!a.path.startsWith('/')&&/^[a-f0-9]{64}$/.test(a.sha256),'invalid asset');ids.add(a.id);}return p;}
export async function createEngine({project=null,renderer='none',scheduler='manual',authorize=()=>false}={}){
 requireOK(['none','auto','webgpu','webgl'].includes(renderer),'invalid renderer');
 if(typeof project==='string'){let url=project.endsWith('.json')?project:project.replace(/\/$/,'')+'/project.json';const r=await fetch(url);requireOK(r.ok,'project fetch failed');project=await r.json();}
 project=project?validateProject(project):{schema:'zge.sdk.project.v1',id:'untitled',name:'Untitled',entryWorld:'main',worlds:{main:null},assets:[],plugins:[],prefabs:{}};
 const kernel=new EngineKernel({id:project.id,scheduler}),types=defaults(),worlds=new Map(),assets=new AssetService();let active=null,disposed=false,presentation=null;
 const alive=()=>requireOK(!disposed,'engine disposed');
 const api={version:SDK_VERSION,renderer,project:copy(project),assets,
 registerComponent(type,validate){alive();requireOK(idOK(type)&&!types.has(type)&&typeof validate==='function','invalid/duplicate component');types.set(type,validate);return api;},
 createWorld(id='main'){alive();requireOK(!worlds.has(id),'duplicate world');const world=new Scene({id,types,prefabs:project.prefabs??{},assetIds:project.assets.map(a=>a.id)});worlds.set(id,world);world.subscribe(e=>kernel.events.emit('scene',e));active=world;return world;},
 async loadWorld(id=project.entryWorld){alive();if(worlds.has(id)){active=worlds.get(id);return active;}requireOK(Object.hasOwn(project.worlds,id),'unknown world');const world=new Scene({id,types,prefabs:project.prefabs??{},assetIds:project.assets.map(a=>a.id)});if(project.worlds[id])world.restore(project.worlds[id]);worlds.set(id,world);world.subscribe(e=>kernel.events.emit('scene',e));active=world;return world;},
 get world(){return active;},
 assetReference(id){alive();const ref=project.assets.find(a=>a.id===id);requireOK(ref,'unknown public asset id');return copy(ref);},
 acquireAsset(id,options){const ref=api.assetReference(id);return assets.acquire(ref.path,options);},
 attachRenderer(backend){alive();requireOK(!presentation&&backend&&typeof backend.render==='function'&&typeof backend.dispose==='function','one owned presentation backend required');presentation=backend;return api;},
 registerSystem({id,phase='simulate',run,dispose}){alive();requireOK(typeof run==='function','system callback required');return kernel.addSystem({id,phase,run:(_world,dt,info)=>run(active,dt,{...info,events:api.events}),dispose});},
 use(plugin){alive();requireOK(kernel.lifecycle.state==='created','plugins register before start');kernel.use({...plugin,install:()=>plugin.install(api),start:plugin.start?()=>plugin.start(api):undefined,stop:plugin.stop?()=>plugin.stop(api):undefined,dispose:plugin.dispose?()=>plugin.dispose(api):undefined});return api;},
 events:{on:(type,fn)=>{alive();return kernel.events.on(type,fn);},emit:(type,data,channel='authoritative')=>{alive();requireOK(['authoritative','visualization'].includes(channel),'invalid event channel');kernel.events.emit(type,{data:plain(data),channel,revision:active?.revision??0});}},
 async start(){alive();if(!active)await api.loadWorld();await kernel.start();return api;},pause(){alive();return kernel.pause();},resume(){alive();return kernel.resume();},
 step(count=1){alive();requireOK(kernel.lifecycle.state==='paused'&&Number.isInteger(count)&&count>0&&count<=120,'step requires pause and 1..120 steps');return kernel.step(count);},
 frame(time){alive();const result=kernel.frame(time);presentation?.sync?.(active?.entities()??[]);presentation?.render();return result;},metrics(){alive();return kernel.diagnostics();},
 inspectEntity(id,{principal=null,includePrivate=false}={}){alive();const entity=active?.findEntity(id);if(!entity)return null;for(const key of ['player','team','ai'])if(Object.hasOwn(entity.components,key)&&(!includePrivate||authorize({principal,capability:`inspect.${key}`,entityId:id})!==true))delete entity.components[key];return entity;},
 async dispose(){if(disposed)return;disposed=true;for(const w of worlds.values())w.clearListeners();worlds.clear();assets.dispose();presentation?.dispose();presentation=null;await kernel.dispose();}
 };return Object.freeze(api);
}
/** Mock only: structured deterministic fixture, with no natural-language inference. */
export function mockProposal(scene,{request='Add a supply crate',kind='add',entityId=null}={}){
 const id=`entity-${scene.serialize().nextId}`;let operations;
 if(kind==='remove')operations=[{type:'DeleteEntity',id:entityId,expectedExists:true}];
 else if(kind==='move')operations=[{type:'UpdateTransform',id:entityId,expectedExists:true,value:{position:[3,.5,2]}}];
 else{requireOK(kind==='add','unknown mock fixture');operations=[{type:'CreateEntity',id,name:'Proposed supply crate',expectedExists:false,components:{transform:transform({position:[3,.5,2]}),mesh:{primitive:'box',color:'#e2ab55'}}}];}
 return{schema:'zge.sdk.proposal.v1',provider:'deterministic-mock-v1',request:String(request),plan:[`${kind} fixture; explicit approval required`],changeset:scene.changeset(operations)};
}
export class ProposalReview {
 #scene;#proposal;#status='pending';
 constructor(scene,proposal){requireOK(proposal?.schema==='zge.sdk.proposal.v1'&&proposal.provider==='deterministic-mock-v1'&&typeof proposal.request==='string'&&Array.isArray(proposal.plan),'invalid proposal');this.#scene=scene;this.#proposal=plain(proposal);}
 get status(){return this.#status;} get proposal(){return copy(this.#proposal);}
 preview(){requireOK(this.#status==='pending','proposal closed');return this.#scene.preview(this.#proposal.changeset);}
 reject(){requireOK(this.#status==='pending','proposal closed');this.#status='rejected';}
 approve({approved=false,actor='local-author'}={}){requireOK(approved===true&&this.#status==='pending','explicit approval required');const revision=this.#scene.commit(this.#proposal.changeset,{actor,source:this.#proposal.provider});this.#status='approved';return revision;}
}

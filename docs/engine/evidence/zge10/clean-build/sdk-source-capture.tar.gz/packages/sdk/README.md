# @zge/sdk · local preview 10

Build from the repository with `npm run build:sdk`. Install the resulting `npm pack ./packages/sdk` artifact into another ESM project. Node ≥18; browser rendering has an explicit Three.js 0.185.0 peer dependency. The core entry has no Three.js, legacy game, network or database imports. The `/three` entry imports no Three copy. The host injects its shared namespace: `createViewport({three:THREE,canvas,renderer:engine.renderer})` after importing `* as THREE` from `three/webgpu`. Both backends share that graph.

```js
import { createEngine } from '@zge/sdk';
const engine = await createEngine({project: './my-world', renderer: 'auto'});
const world = await engine.loadWorld('main');
world.createEntity({name: 'Structure', components: {transform: {position: [0, 0, 0]}}});
await engine.start();
// Manual scheduler by default: your host calls engine.frame(performance.now()).
// Choose scheduler:'auto' for kernel scheduling of systems.
await engine.dispose();
```

String projects fetch `project.json` (or the supplied JSON URL); Node callers supply a manifest object or an absolute HTTP URL. This release does not implement filesystem discovery or arbitrary project code loading. Manifest scene values are embedded versioned data. Trusted application code registers systems/plugins before start.

`Scene` supplies detached `entities()`, `findEntity(id)`, `serialize()`, atomic `restore(scene)`, `createEntity`, `deleteEntity`, `setComponent`, `updateTransform`, `createPrefabInstance`, `changeset`, `preview`, `commit`, `undo`, `redo`, `history`, and `subscribe`. Serialized schemas are `zge.sdk.project.v1`, `zge.sdk.scene.v1`, `zge.sdk.changeset.v1`, `zge.sdk.diff.v1`, `zge.sdk.commit.v1`, `zge.sdk.proposal.v1`. Component data is finite plain JSON; custom validators return exactly true. Standard transform vectors are position, Euler XYZ rotation in radians, and positive scale. No entity parenting, rigidbody solver, terrain streaming or arbitrary scene scripts are claimed.

The SDK owns registries, scene schemas, optimistic authoring transactions, detached reads, revision history, proposals and asset identity mapping; it reuses the existing kernel clock/system/plugin/event/lifecycle implementation and AssetService ownership rather than reimplementing their machinery. It never attaches to a staging world.

Engine methods include `registerComponent(type, validate)`, `registerSystem({id,phase,run(scene,dt,{events})})`, `use(plugin)`, `start/pause/resume/step/frame/dispose`, `metrics`, `inspectEntity`, `assetReference`, `acquireAsset`, and `attachRenderer`. Plugins receive the public engine, not the kernel context. Register before start. Explicit step requires pause and 1–120 fixed steps. The renderer option is a preference for the host; create a viewport from `@zge/sdk/three` with that preference and either attach it for `engine.frame` presentation or render it from the host. Automatic scheduling drives kernel systems; manual presentation remains host controlled.

Private player/team/AI components are removed from `inspectEntity` unless `includePrivate:true` and a synchronous host authorization callback grants `inspect.player`, `inspect.team` or `inspect.ai`. This is a trusted local embedding boundary, not an adversarial JS sandbox. Raw authoring scenes are developer-owned. No server identity, gameplay token, privileged HTTP route or SQL write is provided.

Assets use declared relative paths and SHA-256 identities; `acquireAsset(id, loaderOptions)` resolves a public ID through the project manifest and the existing AssetService loader registry. Loader code is trusted and owns byte verification/format parsing. Declared hashes are not automatically proof of retrieved bytes. Lease `.value` is shared parsed data and must be treated as immutable; `.instantiate()` produces a loader-owned detached mutable clone; callers release leases and dispose detached GPU resources. Watchdog timeouts remain in AssetService. See lifecycle tests and documentation for limits.

All transaction operations require explicit expected entity existence and an exact base revision. Batches validate completely before publication. Undo/redo produce new monotonically increasing revisions; stable generated IDs are not reused by undo. History is bounded to 100 snapshots / 200 commit records and is reset by restore. This is local authoring history, never multiplayer rollback. Save scene JSON separately from runtime gameplay databases.

Mock proposals are fixtures, not natural-language inference. `ProposalReview.preview()` cannot mutate a scene; approval requires `{approved:true}` and revalidates the current revision. Approval records provider/actor provenance; rejection closes the proposal. Trusted application code remains responsible for the human approval UI.

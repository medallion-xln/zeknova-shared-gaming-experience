import {createProject,createEngine,SDKError,ComponentDefinition} from '@zge/sdk';import {createViewport} from '@zge/sdk/three';const p=createProject({id:'typed',name:'Typed world'});const e=await createEngine({project:p});const def:ComponentDefinition={schema:'zge.component.v1',label:'Health',fields:{amount:{type:'number',min:0}}};e.registerComponent('health',def);const w=await e.loadWorld();const entity=w.createEntity({components:{transform:{position:[0,0,0],rotation:[0,0,0],scale:[1,1,1]},health:{amount:10}}});w.updateTransform(entity.id,{position:[1,2,3]});if(entity.components.transform)entity.components.transform.position[0]=1;const error=new SDKError('TEST','Typed error');console.log(error.code);void createViewport;
// @ts-expect-error invalid renderer is rejected by public types
await createEngine({renderer:'magic'});
// @ts-expect-error vectors require three coordinates
w.updateTransform(entity.id,{position:[1,2]});
await e.dispose();
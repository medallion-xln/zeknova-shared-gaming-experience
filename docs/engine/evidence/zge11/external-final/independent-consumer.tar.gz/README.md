# Signal Garden · independent SDK consumer

Run `npm ci --ignore-scripts --offline` with the recorded dependencies available in the npm cache, then `npm test`, `npm run typecheck`, and `npm start`. Open http://127.0.0.1:8801. The SDK dependency is a local packed public artifact; Three is the explicit peer. This directory has no dependency on the ZekNova monorepo.

WASD/arrows move the gardener; collect the orange seed to awaken the beacon. Save/Reload uses this browser origin's storage. Open `project.json` in Studio, edit the scene or reflected gardener properties, Export the complete project, and choose that export in this application's file input. Rules and schemas are data-only public SDK contracts; no arbitrary project code is loaded from JSON.

`game.test.mjs` checks custom rules, objective, verified JSON asset and persistence. `consumer.ts` typechecks the public SDK and renderer entrypoints with strict TypeScript and negative type assertions. This is local integration evidence, not a commercial game release. Palette provenance is in the project manifest; unrelated assets have no implied redistribution license.

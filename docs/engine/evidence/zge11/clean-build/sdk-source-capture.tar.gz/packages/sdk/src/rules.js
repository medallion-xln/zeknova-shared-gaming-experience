/** Data-only rule interpreter; no eval, URL imports or arbitrary project code. */
export function installProjectRules(engine,input=new Set()){
 const rules=engine.exportProject().rules??[];if(!rules.length)return()=>{};
 return engine.registerSystem({id:'project:data-rules',run(scene,dt,{events}){for(const rule of rules){
  const entity=scene.findEntity(rule.entity);if(!entity)continue;
  if(rule.kind==='move'){
   const t=entity.components.transform;if(!t)continue;const x=(input.has('d')||input.has('ArrowRight')?1:0)-(input.has('a')||input.has('ArrowLeft')?1:0),z=(input.has('s')||input.has('ArrowDown')?1:0)-(input.has('w')||input.has('ArrowUp')?1:0);if(x||z)scene.updateTransform(entity.id,{position:[t.position[0]+x*dt*rule.speed,t.position[1],t.position[2]+z*dt*rule.speed]});
  }else if(rule.kind==='collect'){
   const target=scene.findEntity(rule.target),a=entity.components.transform,b=target?.components.transform,component=entity.components[rule.component];if(target&&a&&b&&component&&Math.hypot(...a.position.map((v,i)=>v-b.position[i]))<=rule.radius){scene.commit(scene.changeset([{type:'DeleteEntity',id:target.id,expectedExists:true},{type:'UpdateComponent',id:entity.id,component:rule.component,expectedExists:true,value:{...component,[rule.counter]:(component[rule.counter]??0)+1}}]));events.emit('game:rule',{entity:entity.id,rule:rule.id,outcome:'collected'});}
  }else if(rule.kind==='goal'){
   const source=scene.findEntity(rule.sourceEntity)?.components[rule.sourceComponent],component=entity.components[rule.component];if(component&&!component[rule.property]&&source?.[rule.counter]>=rule.threshold){scene.setComponent(entity.id,rule.component,{...component,[rule.property]:true});events.emit('game:rule',{entity:entity.id,rule:rule.id,outcome:'complete'});}
  }
 }}});
}
